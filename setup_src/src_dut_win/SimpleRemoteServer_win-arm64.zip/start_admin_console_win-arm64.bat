@echo off
cd "C:\hobl_bin\SimpleRemoteServer_win-arm64"
start "" /HIGH SimpleRemoteConsole_Admin_win-arm64
