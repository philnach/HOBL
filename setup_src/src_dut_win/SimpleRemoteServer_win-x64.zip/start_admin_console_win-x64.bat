@echo off
cd "C:\hobl_bin\SimpleRemoteServer_win-x64"
start "" /HIGH SimpleRemoteConsole_Admin_win-x64
